import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link, useLocation } from "wouter";
import { ArrowLeft, Loader2, MapPin, Upload, Check, AlertCircle } from "lucide-react";
import axios from "axios";
import { toast } from "sonner";
import { getItemIcon, getItemColor } from "@/lib/itemIcons";

interface UF {
  sigla: string;
  nome: string;
}

interface City {
  nome: string;
}

export default function CreatePoint() {
  const [, navigate] = useLocation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    whatsapp: "",
    latitude: "",
    longitude: "",
    city: "",
    uf: "",
    street: "",
    number: "",
    neighborhood: "",
  });

  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [imageBase64, setImageBase64] = useState<string>("");
  const [ufs, setUfs] = useState<UF[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [initialPosition, setInitialPosition] = useState<[number, number]>([0, 0]);
  const [currentStep, setCurrentStep] = useState(1);

  const itemsQuery = trpc.items.list.useQuery();
  const createPointMutation = trpc.points.create.useMutation({
    onSuccess: () => {
      toast.success("🎉 Ponto de coleta cadastrado com sucesso!");
      setTimeout(() => navigate("/search"), 1500);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao cadastrar ponto");
    },
  });

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const { latitude, longitude } = position.coords;
        setInitialPosition([latitude, longitude]);
        setFormData((prev) => ({
          ...prev,
          latitude: latitude.toString(),
          longitude: longitude.toString(),
        }));
      });
    }
  }, []);

  // Load UFs
  useEffect(() => {
    axios
      .get<UF[]>("https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome")
      .then((res) => setUfs(res.data))
      .catch((err) => console.error("Failed to load UFs:", err));
  }, []);

  // Load cities when UF changes
  useEffect(() => {
    if (!formData.uf) {
      setCities([]);
      return;
    }

    axios
      .get<City[]>(
        `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${formData.uf}/municipios`
      )
      .then((res) => {
        const cityNames = res.data.map((c) => c.nome).sort();
        setCities(cityNames);
      })
      .catch((err) => console.error("Failed to load cities:", err));
  }, [formData.uf]);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setImageBase64(event.target?.result as string);
      toast.success("Imagem selecionada com sucesso!");
    };
    reader.readAsDataURL(file);
  };

  const handleItemToggle = (itemId: number) => {
    setSelectedItems((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.city || !formData.uf || !formData.street || !formData.number || !formData.neighborhood) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    if (selectedItems.length === 0) {
      toast.error("Selecione pelo menos um tipo de resíduo");
      return;
    }

    if (!imageBase64) {
      toast.error("Selecione uma imagem para o ponto");
      return;
    }

    createPointMutation.mutate({
      name: formData.name,
      email: formData.email,
      whatsapp: formData.whatsapp,
      latitude: formData.latitude,
      longitude: formData.longitude,
      city: formData.city,
      uf: formData.uf,
      street: formData.street,
      number: formData.number,
      neighborhood: formData.neighborhood,
      itemIds: selectedItems,
      imageBase64: imageBase64,
    });
  };

  const isStep1Valid = formData.name && formData.email && formData.whatsapp;
  const isStep2Valid = formData.uf && formData.city;
  const isStep3Valid = selectedItems.length > 0;
  const isStep4Valid = imageBase64;

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="container py-6">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-red-600 hover:text-red-700 font-semibold mb-4 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Voltar
            </a>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Cadastre seu Ponto de Coleta</h1>
          <p className="text-gray-600 mt-2">Preencha as informações abaixo para registrar um novo ponto</p>
        </div>
      </div>

      <div className="container py-8">
        {/* Progress Steps */}
        <div className="mb-12">
          <div className="flex items-center justify-between mb-8">
            {[1, 2, 3, 4].map((step) => (
              <div key={step} className="flex items-center flex-1">
                <button
                  onClick={() => setCurrentStep(step)}
                  className={`w-12 h-12 rounded-full flex items-center justify-center font-bold transition-all ${
                    step <= currentStep
                      ? "bg-gradient-primary text-white shadow-lg"
                      : "bg-gray-200 text-gray-600"
                  }`}
                >
                  {step < currentStep ? <Check className="w-6 h-6" /> : step}
                </button>
                {step < 4 && (
                  <div
                    className={`flex-1 h-1 mx-2 rounded-full transition-all ${
                      step < currentStep ? "bg-gradient-primary" : "bg-gray-200"
                    }`}
                  ></div>
                )}
              </div>
            ))}
          </div>
          <div className="flex justify-between text-sm font-medium">
            <span className={currentStep === 1 ? "text-red-600" : "text-gray-600"}>Dados Básicos</span>
            <span className={currentStep === 2 ? "text-red-600" : "text-gray-600"}>Localização</span>
            <span className={currentStep === 3 ? "text-red-600" : "text-gray-600"}>Resíduos</span>
            <span className={currentStep === 4 ? "text-red-600" : "text-gray-600"}>Imagem</span>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="max-w-2xl mx-auto">
          {/* Step 1: Basic Info */}
          {currentStep === 1 && (
            <Card className="p-8 bg-white border border-gray-200 rounded-2xl shadow-lg animate-fade-in-up">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Informações Básicas</h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Nome do Ponto *
                  </label>
                  <Input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="Ex: Centro de Reciclagem ABC"
                    className="input-focus"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Email *
                  </label>
                  <Input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="contato@exemplo.com"
                    className="input-focus"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    WhatsApp *
                  </label>
                  <Input
                    type="tel"
                    name="whatsapp"
                    value={formData.whatsapp}
                    onChange={handleInputChange}
                    placeholder="(11) 99999-9999"
                    className="input-focus"
                  />
                </div>
              </div>
              <div className="flex gap-4 mt-8">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => navigate("/")}
                >
                  Cancelar
                </Button>
                <Button
                  type="button"
                  onClick={() => isStep1Valid && setCurrentStep(2)}
                  disabled={!isStep1Valid}
                  className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-300"
                >
                  Próximo
                </Button>
              </div>
            </Card>
          )}

          {/* Step 2: Location */}
          {currentStep === 2 && (
            <Card className="p-8 bg-white border border-gray-200 rounded-2xl shadow-lg animate-fade-in-up">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Localização</h2>
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Estado *
                  </label>
                  <select
                    name="uf"
                    value={formData.uf}
                    onChange={handleInputChange}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent"
                  >
                    <option value="">Selecione um estado</option>
                    {ufs.map((uf) => (
                      <option key={uf.sigla} value={uf.sigla}>
                        {uf.nome}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Cidade *
                  </label>
                  <select
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    disabled={!formData.uf}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent disabled:bg-gray-100"
                  >
                    <option value="">Selecione uma cidade</option>
                    {cities.map((city) => (
                      <option key={city} value={city}>
                        {city}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Rua *
                  </label>
                  <Input
                    type="text"
                    name="street"
                    value={formData.street}
                    onChange={handleInputChange}
                    placeholder="Ex: Avenida Paulista"
                    className="input-focus"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">
                      Número *
                    </label>
                    <Input
                      type="text"
                      name="number"
                      value={formData.number}
                      onChange={handleInputChange}
                      placeholder="Ex: 1000"
                      className="input-focus"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">
                      Bairro *
                    </label>
                    <Input
                      type="text"
                      name="neighborhood"
                      value={formData.neighborhood}
                      onChange={handleInputChange}
                      placeholder="Ex: Bela Vista"
                      className="input-focus"
                    />
                  </div>
                </div>
                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <p className="text-sm text-blue-900">
                    <MapPin className="w-4 h-4 inline mr-2" />
                    A localização será detectada automaticamente via GPS do seu dispositivo.
                  </p>
                </div>
              </div>
              <div className="flex gap-4 mt-8">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setCurrentStep(1)}
                >
                  Voltar
                </Button>
                <Button
                  type="button"
                  onClick={() => isStep2Valid && setCurrentStep(3)}
                  disabled={!isStep2Valid}
                  className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-300"
                >
                  Próximo
                </Button>
              </div>
            </Card>
          )}

          {/* Step 3: Items */}
          {currentStep === 3 && (
            <Card className="p-8 bg-white border border-gray-200 rounded-2xl shadow-lg animate-fade-in-up">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Tipos de Resíduo</h2>
              <p className="text-gray-600 mb-6">Selecione os tipos de resíduo que seu ponto coleta *</p>
              <div className="grid grid-cols-2 gap-4 mb-8">
                {itemsQuery.data?.map((item) => {
                  const Icon = getItemIcon(item.title);
                  const color = getItemColor(item.title);
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => handleItemToggle(item.id)}
                      className={`p-4 rounded-xl border-2 transition-all flex items-center gap-3 ${
                        selectedItems.includes(item.id)
                          ? "border-red-600 bg-red-50"
                          : "border-gray-200 bg-white hover:border-red-300"
                      }`}
                    >
                      <Icon className={`w-5 h-5 ${color} flex-shrink-0`} />
                      <div className="text-left">
                        <div className="flex items-center gap-2">
                          <div
                            className={`w-5 h-5 rounded border-2 flex items-center justify-center ${
                              selectedItems.includes(item.id)
                                ? "bg-red-600 border-red-600"
                                : "border-gray-300"
                            }`}
                          >
                            {selectedItems.includes(item.id) && (
                              <Check className="w-3 h-3 text-white" />
                            )}
                          </div>
                        </div>
                      </div>
                      <span className="text-sm font-medium text-gray-900 flex-1 text-left">{item.title}</span>
                    </button>
                  );
                })}
              </div>
              <div className="flex gap-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setCurrentStep(2)}
                >
                  Voltar
                </Button>
                <Button
                  type="button"
                  onClick={() => isStep3Valid && setCurrentStep(4)}
                  disabled={!isStep3Valid}
                  className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-300"
                >
                  Próximo
                </Button>
              </div>
            </Card>
          )}

          {/* Step 4: Image */}
          {currentStep === 4 && (
            <Card className="p-8 bg-white border border-gray-200 rounded-2xl shadow-lg animate-fade-in-up">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Foto do Ponto</h2>
              <div className="mb-8">
                {imageBase64 ? (
                  <div className="relative">
                    <img
                      src={imageBase64}
                      alt="Preview"
                      className="w-full h-64 object-cover rounded-xl border-2 border-green-300 bg-green-50"
                    />
                    <div className="absolute top-4 right-4 bg-green-500 text-white px-3 py-1 rounded-full text-sm font-semibold flex items-center gap-2">
                      <Check className="w-4 h-4" />
                      Selecionada
                    </div>
                  </div>
                ) : (
                  <label className="block border-2 border-dashed border-gray-300 rounded-xl p-8 text-center cursor-pointer hover:border-red-500 hover:bg-red-50 transition-all">
                    <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-900 font-semibold mb-2">Clique para selecionar uma imagem</p>
                    <p className="text-sm text-gray-600">PNG, JPG até 10MB</p>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageUpload}
                      className="hidden"
                    />
                  </label>
                )}
              </div>
              <div className="flex gap-4">
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1"
                  onClick={() => setCurrentStep(3)}
                >
                  Voltar
                </Button>
                <Button
                  type="submit"
                  disabled={!isStep4Valid || createPointMutation.isPending}
                  className="flex-1 bg-green-600 hover:bg-green-700 disabled:bg-gray-300"
                >
                  {createPointMutation.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Cadastrando...
                    </>
                  ) : (
                    <>
                      <Check className="w-4 h-4 mr-2" />
                      Cadastrar Ponto
                    </>
                  )}
                </Button>
              </div>
            </Card>
          )}
        </form>
      </div>
    </div>
  );
}
