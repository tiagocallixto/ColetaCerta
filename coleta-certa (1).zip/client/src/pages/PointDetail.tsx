import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, Mail, Phone, MapPin, Loader2 } from "lucide-react";

export default function PointDetail() {
  const params = useParams();
  const pointId = params?.id ? parseInt(params.id) : 0;

  const pointQuery = trpc.points.getById.useQuery(
    { id: pointId },
    { enabled: pointId > 0 }
  );

  if (pointQuery.isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-primary animate-spin" />
      </div>
    );
  }

  if (pointQuery.isError || !pointQuery.data) {
    return (
      <div className="min-h-screen bg-slate-50">
        <div className="container py-8">
          <Link href="/search">
            <a className="inline-block">
              <Button variant="ghost" size="sm" className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </a>
          </Link>
          <div className="text-center py-12">
            <p className="text-slate-600">Ponto de coleta não encontrado.</p>
          </div>
        </div>
      </div>
    );
  }

  const point = pointQuery.data;

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Navigation header with back button */}
      <div className="bg-white border-b border-slate-200">
        <div className="container py-6">
          <Link href="/search">
            <a className="inline-block">
              <Button variant="ghost" size="sm" className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </a>
          </Link>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Point details and information */}
          <div className="lg:col-span-2 space-y-6">
            {/* Featured image of the collection point */}
            {point.image && (
              <div className="rounded-lg overflow-hidden h-96 bg-slate-200">
                <img
                  src={point.image}
                  alt={point.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* Basic information: name, contact, location */}
            <Card className="p-6 border-slate-200">
              <h1 className="text-3xl font-bold text-slate-900 mb-4">
                {point.name}
              </h1>

              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-slate-600">Localização</p>
                    <p className="text-slate-900 font-medium">
                      {point.city}, {point.uf}
                    </p>
                    <p className="text-sm text-slate-600">
                      Lat: {point.latitude}, Lon: {point.longitude}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Mail className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-slate-600">Email</p>
                    <a
                      href={`mailto:${point.email}`}
                      className="text-primary hover:underline font-medium"
                    >
                      {point.email}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-5 h-5 text-primary mt-1 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-slate-600">WhatsApp</p>
                    <a
                      href={`https://wa.me/${point.whatsapp.replace(/\D/g, "")}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-primary hover:underline font-medium"
                    >
                      {point.whatsapp}
                    </a>
                  </div>
                </div>
              </div>
            </Card>

            {/* Items */}
            <Card className="p-6 border-slate-200">
              <h2 className="text-xl font-semibold text-slate-900 mb-4">
                Tipos de Resíduo Aceitos
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {point.items.map((item) => (
                  <div
                    key={item.id}
                    className="p-4 bg-slate-50 rounded-lg text-center hover:bg-slate-100 transition-colors"
                  >
                    {item.image && (
                      <img
                        src={`/uploads/${item.image}`}
                        alt={item.title}
                        className="w-12 h-12 mx-auto mb-2"
                      />
                    )}
                    <p className="text-sm font-medium text-slate-900">
                      {item.title}
                    </p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 border-slate-200 sticky top-20 space-y-4">
              <h2 className="text-lg font-semibold text-slate-900">
                Entrar em Contato
              </h2>
              <p className="text-sm text-slate-600">
                Clique nos botões abaixo para entrar em contato com este ponto
                de coleta.
              </p>

              <a
                href={`mailto:${point.email}`}
                className="block"
              >
                <Button className="w-full" variant="outline">
                  <Mail className="w-4 h-4 mr-2" />
                  Enviar Email
                </Button>
              </a>

              <a
                href={`https://wa.me/${point.whatsapp.replace(/\D/g, "")}`}
                target="_blank"
                rel="noopener noreferrer"
                className="block"
              >
                <Button className="w-full bg-green-600 hover:bg-green-700 text-white">
                  <Phone className="w-4 h-4 mr-2" />
                  WhatsApp
                </Button>
              </a>

              <div className="bg-slate-50 p-4 rounded-lg">
                <p className="text-xs text-slate-600">
                  <strong>Dica:</strong> Antes de visitar, entre em contato para
                  confirmar o horário de funcionamento.
                </p>
              </div>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
