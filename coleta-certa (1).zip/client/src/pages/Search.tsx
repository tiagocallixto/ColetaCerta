import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, MapPin, Mail, Phone, Loader2, Search as SearchIcon, Filter, X } from "lucide-react";
import axios from "axios";
import { getItemIcon, getItemColor } from "@/lib/itemIcons";

interface UF {
  sigla: string;
  nome: string;
}

interface City {
  nome: string;
}

export default function Search() {
  const [selectedUf, setSelectedUf] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [ufs, setUfs] = useState<UF[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(true);

  const itemsQuery = trpc.items.list.useQuery();
  const searchPointsQuery = trpc.points.search.useQuery(
    {
      city: selectedCity || "",
      uf: selectedUf || "",
      itemIds: selectedItems,
    },
    {
      enabled: Boolean(selectedCity && selectedUf && selectedItems.length > 0),
    }
  );

  // Initialize state with available Brazilian states
  useEffect(() => {
    axios
      .get<UF[]>("https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome")
      .then((res) => setUfs(res.data))
      .catch((err) => console.error("Failed to load UFs:", err));
  }, []);

  // Fetch cities for the selected state
  useEffect(() => {
    if (!selectedUf) {
      setCities([]);
      return;
    }

    axios
      .get<City[]>(
        `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${selectedUf}/municipios`
      )
      .then((res) => {
        const cityNames = res.data.map((c) => c.nome).sort();
        setCities(cityNames);
      })
      .catch((err) => console.error("Failed to load cities:", err));
  }, [selectedUf]);

  const handleItemToggle = (itemId: number) => {
    setSelectedItems((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  const isLoading = searchPointsQuery.isLoading;
  const points = searchPointsQuery.data || [];

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white">
      {/* Page header with navigation */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40 shadow-sm">
        <div className="container py-6">
          <Link href="/">
            <a className="inline-flex items-center gap-2 text-red-600 hover:text-red-700 font-semibold mb-4 transition-colors">
              <ArrowLeft className="w-5 h-5" />
              Voltar
            </a>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900">Encontre Pontos de Coleta</h1>
          <p className="text-gray-600 mt-2">Filtre por localização e tipo de resíduo</p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Search filters panel */}
          <div className={`lg:col-span-1 ${showFilters ? "block" : "hidden"} lg:block`}>
            <div className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100 sticky top-24">
              <div className="flex items-center justify-between mb-6 lg:hidden">
                <h2 className="text-lg font-bold text-gray-900">Filtros</h2>
                <button onClick={() => setShowFilters(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* UF Filter */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-900 mb-3">Estado</label>
                <select
                  value={selectedUf}
                  onChange={(e) => {
                    setSelectedUf(e.target.value);
                    setSelectedCity("");
                  }}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent transition-all"
                >
                  <option value="">Selecione um estado</option>
                  {ufs.map((uf) => (
                    <option key={uf.sigla} value={uf.sigla}>
                      {uf.nome}
                    </option>
                  ))}
                </select>
              </div>

              {/* City Filter */}
              <div className="mb-6">
                <label className="block text-sm font-semibold text-gray-900 mb-3">Cidade</label>
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  disabled={!selectedUf}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed transition-all"
                >
                  <option value="">Selecione uma cidade</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>

              {/* Items Filter */}
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-3">Tipos de Resíduo</label>
                <div className="space-y-2 max-h-96 overflow-y-auto">
                  {itemsQuery.data?.map((item) => {
                    const Icon = getItemIcon(item.title);
                    const color = getItemColor(item.title);
                    return (
                      <label
                        key={item.id}
                        className="flex items-center gap-3 p-3 rounded-lg cursor-pointer hover:bg-red-50 transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={selectedItems.includes(item.id)}
                          onChange={() => handleItemToggle(item.id)}
                          className="w-4 h-4 text-red-600 rounded cursor-pointer"
                        />
                        <Icon className={`w-4 h-4 ${color} flex-shrink-0`} />
                        <span className="text-sm text-gray-700 flex-1">{item.title}</span>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Clear Filters */}
              {(selectedUf || selectedCity || selectedItems.length > 0) && (
                <button
                  onClick={() => {
                    setSelectedUf("");
                    setSelectedCity("");
                    setSelectedItems([]);
                  }}
                  className="w-full mt-6 px-4 py-2 text-sm text-red-600 hover:bg-red-50 rounded-lg transition-colors font-medium"
                >
                  Limpar Filtros
                </button>
              )}
            </div>
          </div>

          {/* Results */}
          <div className="lg:col-span-3">
            {/* Mobile Filter Toggle */}
            <div className="lg:hidden mb-6">
              <button
                onClick={() => setShowFilters(true)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-white border border-gray-300 rounded-lg font-semibold text-gray-900 hover:bg-gray-50 transition-colors"
              >
                <Filter className="w-5 h-5" />
                Mostrar Filtros
              </button>
            </div>

            {/* Results Header */}
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-gray-900">
                {isLoading ? "Buscando..." : `${points.length} ponto${points.length !== 1 ? "s" : ""} encontrado${points.length !== 1 ? "s" : ""}`}
              </h2>
              {selectedCity && selectedUf && (
                <p className="text-gray-600 mt-2">
                  em <span className="font-semibold">{selectedCity}, {selectedUf}</span>
                </p>
              )}
            </div>

            {/* Loading State */}
            {isLoading && (
              <div className="flex items-center justify-center py-12">
                <div className="text-center">
                  <Loader2 className="w-12 h-12 text-red-600 animate-spin mx-auto mb-4" />
                  <p className="text-gray-600">Buscando pontos de coleta...</p>
                </div>
              </div>
            )}

            {/* Empty State */}
            {!isLoading && points.length === 0 && selectedCity && selectedUf && (
              <div className="bg-white rounded-2xl p-12 text-center border border-gray-200">
                <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-900 mb-2">Nenhum ponto encontrado</h3>
                <p className="text-gray-600">Tente ajustar seus filtros ou escolher outra localização.</p>
              </div>
            )}

            {/* Results Grid */}
            {!isLoading && points.length > 0 && (
              <div className="grid gap-6">
                {points.map((point) => (
                  <Link key={point.id} href={`/point/${point.id}`}>
                    <a className="block">
                      <Card className="card-hover bg-white border border-gray-200 rounded-2xl overflow-hidden hover:border-red-300 group">
                        <div className="p-6">
                          <div className="flex items-start justify-between mb-4">
                            <div className="flex-1">
                              <h3 className="text-xl font-bold text-gray-900 group-hover:text-red-600 transition-colors">
                                {point.name}
                              </h3>
                              <div className="flex items-center gap-2 text-gray-600 mt-2">
                                <MapPin className="w-4 h-4 text-red-600" />
                                <span className="text-sm">{point.city}, {point.uf}</span>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-50 rounded-full">
                                <span className="text-xs font-semibold text-red-600">Ver Detalhes</span>
                              </div>
                            </div>
                          </div>

                          {/* Contact Info */}
                          <div className="flex flex-col sm:flex-row gap-4 mb-4 pt-4 border-t border-gray-100">
                            <a
                              href={`mailto:${point.email}`}
                              className="flex items-center gap-2 text-sm text-gray-600 hover:text-red-600 transition-colors"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <Mail className="w-4 h-4" />
                              {point.email}
                            </a>
                            <a
                              href={`https://wa.me/${point.whatsapp}`}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="flex items-center gap-2 text-sm text-gray-600 hover:text-green-600 transition-colors"
                              onClick={(e) => e.stopPropagation()}
                            >
                              <Phone className="w-4 h-4" />
                              {point.whatsapp}
                            </a>
                          </div>

                          {/* Items with Icons */}
                          <div className="flex flex-wrap gap-2">
                            {itemsQuery.data
                              ?.filter((item) => Math.random() > 0.5)
                              .slice(0, 3)
                              .map((item) => {
                                const Icon = getItemIcon(item.title);
                                const color = getItemColor(item.title);
                                return (
                                  <span
                                    key={item.id}
                                    className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r from-red-50 to-orange-50 text-red-700 border border-red-200"
                                  >
                                    <Icon className={`w-3 h-3 ${color}`} />
                                    {item.title}
                                  </span>
                                );
                              })}
                          </div>
                        </div>
                      </Card>
                    </a>
                  </Link>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
