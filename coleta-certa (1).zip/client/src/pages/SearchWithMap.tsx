import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { MapView } from "@/components/Map";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";
import { ArrowLeft, MapPin, Mail, Phone, Loader2, Zap } from "lucide-react";
import axios from "axios";

interface UF {
  sigla: string;
  nome: string;
}

interface City {
  nome: string;
}

interface SearchPoint {
  id: number;
  name: string;
  email: string;
  whatsapp: string;
  latitude: string;
  longitude: string;
  city: string;
  uf: string;
  image: string;
}

export default function SearchWithMap() {
  const [selectedUf, setSelectedUf] = useState("");
  const [selectedCity, setSelectedCity] = useState("");
  const [selectedItems, setSelectedItems] = useState<number[]>([]);
  const [ufs, setUfs] = useState<UF[]>([]);
  const [cities, setCities] = useState<string[]>([]);
  const [searchRadius, setSearchRadius] = useState(5); // km
  const [mapCenter, setMapCenter] = useState<{ lat: number; lng: number }>({
    lat: -15.7942,
    lng: -47.8822,
  }); // Brazil center
  const [selectedLocation, setSelectedLocation] = useState<{
    lat: number;
    lng: number;
  } | null>(null);

  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.marker.AdvancedMarkerElement[]>([]);
  const radiusCircleRef = useRef<google.maps.Circle | null>(null);

  const itemsQuery = trpc.items.list.useQuery();
  const searchPointsQuery = trpc.points.search.useQuery(
    {
      city: selectedCity || "",
      uf: selectedUf || "",
      itemIds: selectedItems,
    },
    {
      enabled: Boolean(selectedCity && selectedUf && selectedItems.length > 0),
    }
  );

  // Fetch Brazilian states on component mount
  useEffect(() => {
    axios
      .get<UF[]>("https://servicodados.ibge.gov.br/api/v1/localidades/estados?orderBy=nome")
      .then((res) => setUfs(res.data))
      .catch((err) => console.error("Failed to load UFs:", err));
  }, []);

  // Update city list whenever user selects a different state
  useEffect(() => {
    if (!selectedUf) {
      setCities([]);
      return;
    }

    axios
      .get<City[]>(
        `https://servicodados.ibge.gov.br/api/v1/localidades/estados/${selectedUf}/municipios`
      )
      .then((res) => {
        const cityNames = res.data.map((c) => c.nome).sort();
        setCities(cityNames);
      })
      .catch((err) => console.error("Failed to load cities:", err));
  }, [selectedUf]);

  const handleItemToggle = (itemId: number) => {
    setSelectedItems((prev) =>
      prev.includes(itemId)
        ? prev.filter((id) => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handleMapReady = (map: google.maps.Map) => {
    mapRef.current = map;

    // Listen for map clicks to set location
    map.addListener("click", (event: google.maps.MapMouseEvent) => {
      if (event.latLng) {
        const lat = event.latLng.lat();
        const lng = event.latLng.lng();
        setSelectedLocation({ lat, lng });
        setMapCenter({ lat, lng });

        // Update radius circle
        if (radiusCircleRef.current) {
          radiusCircleRef.current.setCenter({ lat, lng });
        }
      }
    });
  };

  // Update markers and radius circle when search results change
  useEffect(() => {
    if (!mapRef.current) return;

    // Clear existing markers
    markersRef.current.forEach((marker) => {
      marker.map = null;
    });
    markersRef.current = [];

    // Clear radius circle
    if (radiusCircleRef.current) {
      radiusCircleRef.current.setMap(null);
      radiusCircleRef.current = null;
    }

    const points = searchPointsQuery.data || [];

    // Add markers for search results
    points.forEach((point) => {
      const lat = parseFloat(point.latitude);
      const lng = parseFloat(point.longitude);

      if (!isNaN(lat) && !isNaN(lng)) {
        const marker = new google.maps.marker.AdvancedMarkerElement({
          map: mapRef.current!,
          position: { lat, lng },
          title: point.name,
        });

        // Add click listener to marker
        marker.addListener("click", () => {
          mapRef.current?.setCenter({ lat, lng });
          mapRef.current?.setZoom(16);
        });

        markersRef.current.push(marker);
      }
    });

    // Draw radius circle if location is selected
    if (selectedLocation && mapRef.current) {
      radiusCircleRef.current = new google.maps.Circle({
        map: mapRef.current,
        center: selectedLocation,
        radius: searchRadius * 1000, // Convert km to meters
        fillColor: "#f97316",
        fillOpacity: 0.1,
        strokeColor: "#f97316",
        strokeOpacity: 0.4,
        strokeWeight: 2,
      });

      // Center map on selected location
      mapRef.current.setCenter(selectedLocation);
      mapRef.current.setZoom(14);
    }
  }, [searchPointsQuery.data, selectedLocation, searchRadius]);

  const isLoading = searchPointsQuery.isLoading;
  const points = searchPointsQuery.data || [];

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="container py-6">
          <Link href="/">
            <a className="inline-block">
              <Button variant="ghost" size="sm" className="mb-4">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Voltar
              </Button>
            </a>
          </Link>
          <h1 className="text-3xl font-bold text-slate-900">
            Buscar Pontos de Coleta
          </h1>
          <p className="text-slate-600 mt-2">
            Use o mapa para encontrar pontos de coleta próximos a você
          </p>
        </div>
      </div>

      <div className="container py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg p-6 border border-slate-200 sticky top-20 space-y-6">
              <h2 className="text-lg font-semibold text-slate-900">Filtros</h2>

              {/* UF Filter */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Estado
                </label>
                <select
                  value={selectedUf}
                  onChange={(e) => {
                    setSelectedUf(e.target.value);
                    setSelectedCity("");
                  }}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="">Selecione um estado</option>
                  {ufs.map((uf) => (
                    <option key={uf.sigla} value={uf.sigla}>
                      {uf.nome}
                    </option>
                  ))}
                </select>
              </div>

              {/* City Filter */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Cidade
                </label>
                <select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  disabled={!selectedUf}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary disabled:opacity-50"
                >
                  <option value="">Selecione uma cidade</option>
                  {cities.map((city) => (
                    <option key={city} value={city}>
                      {city}
                    </option>
                  ))}
                </select>
              </div>

              {/* Radius Filter */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-2">
                  Raio de Busca: {searchRadius} km
                </label>
                <input
                  type="range"
                  min="1"
                  max="50"
                  value={searchRadius}
                  onChange={(e) => setSearchRadius(parseInt(e.target.value))}
                  className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-primary"
                />
              </div>

              {/* Items Filter */}
              <div>
                <label className="block text-sm font-medium text-slate-700 mb-3">
                  Tipos de Resíduo
                </label>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {itemsQuery.data?.map((item) => (
                    <label
                      key={item.id}
                      className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-50 cursor-pointer"
                    >
                      <input
                        type="checkbox"
                        checked={selectedItems.includes(item.id)}
                        onChange={() => handleItemToggle(item.id)}
                        className="w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary"
                      />
                      <span className="text-sm text-slate-700">{item.title}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Info Box */}
              <div className="bg-blue-50 p-3 rounded-lg border border-blue-200">
                <p className="text-xs text-blue-700">
                  <strong>💡 Dica:</strong> Clique no mapa para selecionar uma localização e visualizar o raio de busca.
                </p>
              </div>
            </div>
          </div>

          {/* Map and Results */}
          <div className="lg:col-span-3 space-y-6">
            {/* Map */}
            <Card className="p-4 border-slate-200 overflow-hidden">
              <div className="mb-3">
                <p className="text-sm text-slate-600">
                  {selectedLocation
                    ? `📍 Localização selecionada: ${selectedLocation.lat.toFixed(4)}, ${selectedLocation.lng.toFixed(4)}`
                    : "Clique no mapa para selecionar uma localização"}
                </p>
              </div>
              <MapView
                initialCenter={mapCenter}
                initialZoom={12}
                onMapReady={handleMapReady}
                className="rounded-lg"
              />
            </Card>

            {/* Results */}
            <div>
              <h3 className="text-lg font-semibold text-slate-900 mb-4">
                {isLoading ? "Carregando..." : `${points.length} ponto(s) encontrado(s)`}
              </h3>

              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 text-primary animate-spin" />
                </div>
              ) : points.length > 0 ? (
                <div className="grid gap-4">
                  {points.map((point) => (
                    <Link key={point.id} href={`/point/${point.id}`}>
                      <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer border-slate-200">
                        <div className="flex gap-4">
                          {point.image && (
                            <img
                              src={point.image}
                              alt={point.name}
                              className="w-24 h-24 rounded-lg object-cover"
                            />
                          )}
                          <div className="flex-1">
                            <h3 className="text-lg font-semibold text-slate-900 mb-2">
                              {point.name}
                            </h3>
                            <div className="space-y-1 text-sm text-slate-600">
                              <div className="flex items-center gap-2">
                                <MapPin className="w-4 h-4" />
                                {point.city}, {point.uf}
                              </div>
                              <div className="flex items-center gap-2">
                                <Mail className="w-4 h-4" />
                                {point.email}
                              </div>
                              <div className="flex items-center gap-2">
                                <Phone className="w-4 h-4" />
                                {point.whatsapp}
                              </div>
                            </div>
                          </div>
                        </div>
                      </Card>
                    </Link>
                  ))}
                </div>
              ) : selectedCity && selectedUf && selectedItems.length > 0 ? (
                <div className="text-center py-12">
                  <Zap className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">
                    Nenhum ponto de coleta encontrado com esses filtros.
                  </p>
                </div>
              ) : (
                <div className="text-center py-12">
                  <MapPin className="w-12 h-12 text-slate-300 mx-auto mb-4" />
                  <p className="text-slate-600">
                    Selecione um estado, cidade e pelo menos um tipo de resíduo para buscar.
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
