import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { APP_LOGO, APP_TITLE, getLoginUrl } from "@/const";
import { Link } from "wouter";
import { ArrowRight, Leaf, MapPin, Zap, Recycle, Users, TrendingUp } from "lucide-react";

export default function Home() {
  const { user, loading, isAuthenticated } = useAuth();

  return (
    <div className="min-h-screen bg-white">
      {/* Top navigation bar with branding and auth links */}
      <nav className="border-b border-gray-100 bg-white/95 backdrop-blur-sm sticky top-0 z-50 shadow-sm">
        <div className="container flex items-center justify-between py-4">
          <div className="flex items-center gap-3 animate-fade-in-up">
            <div className="w-10 h-10 gradient-primary rounded-lg flex items-center justify-center shadow-lg">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gradient">{APP_TITLE}</span>
          </div>
          <div className="flex items-center gap-4">
            {isAuthenticated ? (
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-600 font-medium">{user?.name || "Usuário"}</span>
                <Link href="/dashboard">
                  <Button variant="outline" size="sm" className="hover:bg-gray-50">
                    Dashboard
                  </Button>
                </Link>
              </div>
            ) : (
              <a href={getLoginUrl()}>
                <Button size="sm" className="bg-red-600 hover:bg-red-700 shadow-md hover:shadow-lg">
                  Entrar
                </Button>
              </a>
            )}
          </div>
        </div>
      </nav>

      {/* Main landing area with CTA buttons */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="absolute inset-0 gradient-light opacity-40"></div>
        <div className="container relative z-10">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            {/* Headline and primary CTAs */}
            <div className="space-y-8 animate-slide-in-left">
              <div className="space-y-6">
                <h1 className="text-6xl md:text-7xl font-bold leading-tight">
                  <span className="text-gray-900">Coleta</span>
                  <br />
                  <span className="text-gradient">Certa</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed max-w-lg">
                  Encontre os melhores pontos de coleta de resíduos próximo a você. Contribua para um futuro mais sustentável e faça a diferença.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/search-map">
                  <a className="inline-block">
                    <Button size="lg" className="btn-primary w-full sm:w-auto group">
                      <MapPin className="w-5 h-5 mr-2 group-hover:animate-bounce" />
                      Buscar Pontos com Mapa
                      <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </a>
                </Link>
                <Link href="/create-point">
                  <a className="inline-block">
                    <Button size="lg" className="btn-secondary w-full sm:w-auto group">
                      <Recycle className="w-5 h-5 mr-2" />
                      Cadastrar Ponto
                    </Button>
                  </a>
                </Link>
              </div>

              {/* Key metrics to build trust */}
              <div className="grid grid-cols-3 gap-6 pt-8">
                <div className="card-hover p-4 rounded-lg bg-gradient-to-br from-red-50 to-orange-50">
                  <div className="text-3xl font-bold text-gradient">500+</div>
                  <p className="text-sm text-gray-600 mt-1">Pontos</p>
                </div>
                <div className="card-hover p-4 rounded-lg bg-gradient-to-br from-red-50 to-orange-50">
                  <div className="text-3xl font-bold text-gradient">10k+</div>
                  <p className="text-sm text-gray-600 mt-1">Usuários</p>
                </div>
                <div className="card-hover p-4 rounded-lg bg-gradient-to-br from-red-50 to-orange-50">
                  <div className="text-3xl font-bold text-gradient">24/7</div>
                  <p className="text-sm text-gray-600 mt-1">Disponível</p>
                </div>
              </div>
            </div>

            {/* Right Visual */}
            <div className="relative hidden md:block animate-slide-in-right">
              <div className="absolute -inset-4 gradient-primary rounded-3xl blur-3xl opacity-20"></div>
              <div className="relative bg-white rounded-3xl p-8 shadow-2xl border border-gray-100">
                <div className="space-y-6">
                  {/* Feature Cards */}
                  {[
                    {
                      icon: MapPin,
                      title: "Localização Precisa",
                      desc: "Encontre pontos perto de você",
                      color: "text-red-600",
                    },
                    {
                      icon: Zap,
                      title: "Rápido e Fácil",
                      desc: "Cadastre em poucos minutos",
                      color: "text-orange-600",
                    },
                    {
                      icon: Leaf,
                      title: "Sustentável",
                      desc: "Ajude o meio ambiente",
                      color: "text-green-600",
                    },
                  ].map((feature, idx) => (
                    <div
                      key={idx}
                      className="card-hover flex gap-4 p-4 rounded-xl bg-gradient-to-br from-gray-50 to-gray-100 hover:from-red-50 hover:to-orange-50"
                    >
                      <div className={`flex-shrink-0 w-12 h-12 rounded-lg bg-white flex items-center justify-center shadow-md ${feature.color}`}>
                        <feature.icon className="w-6 h-6" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900">{feature.title}</h3>
                        <p className="text-sm text-gray-600">{feature.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
        <div className="container">
          <div className="text-center mb-16 animate-fade-in-up">
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">Como Funciona</h2>
            <p className="text-xl text-gray-600">Três passos simples para fazer a diferença</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "01",
                title: "Busque",
                desc: "Procure pelos pontos de coleta mais próximos de você usando filtros de localização e tipo de resíduo.",
                icon: MapPin,
              },
              {
                step: "02",
                title: "Selecione",
                desc: "Escolha o ponto de coleta que melhor se adequa às suas necessidades e veja os detalhes.",
                icon: Recycle,
              },
              {
                step: "03",
                title: "Contribua",
                desc: "Leve seus resíduos para o ponto selecionado e contribua para um planeta mais limpo.",
                icon: Leaf,
              },
            ].map((item, idx) => (
              <div
                key={idx}
                className="card-hover group relative bg-white rounded-2xl p-8 shadow-lg border border-gray-100 hover:border-red-200"
              >
                <div className="absolute -top-6 left-8 w-12 h-12 gradient-primary rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                  {item.step}
                </div>
                <div className="mt-4 space-y-4">
                  <item.icon className="w-8 h-8 text-red-600 group-hover:animate-float" />
                  <h3 className="text-2xl font-bold text-gray-900">{item.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="relative py-20 overflow-hidden">
        <div className="absolute inset-0 gradient-primary opacity-90"></div>
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 right-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        </div>
        <div className="container relative z-10 text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6 animate-fade-in-up">
            Pronto para começar?
          </h2>
          <p className="text-xl text-white/90 mb-8 max-w-2xl mx-auto">
            Junte-se a milhares de pessoas que já estão fazendo a diferença. Cadastre seu ponto de coleta hoje.
          </p>
          <Link href="/create-point">
            <a className="inline-block">
              <Button size="lg" className="bg-white text-red-600 hover:bg-gray-100 shadow-xl hover:shadow-2xl">
                Cadastrar Agora
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </a>
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-300 py-16">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 gradient-primary rounded-lg flex items-center justify-center">
                  <Leaf className="w-5 h-5 text-white" />
                </div>
                <span className="text-white font-bold">{APP_TITLE}</span>
              </div>
              <p className="text-sm text-gray-400">Conectando pessoas a pontos de coleta sustentáveis.</p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Produto</h4>
              <ul className="space-y-2 text-sm">
                <li><Link href="/search-map"><a className="hover:text-white transition">Buscar Pontos</a></Link></li>
                <li><Link href="/create-point"><a className="hover:text-white transition">Cadastrar</a></Link></li>
                <li><a href="#" className="hover:text-white transition">Sobre</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Suporte</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Ajuda</a></li>
                <li><a href="#" className="hover:text-white transition">Contato</a></li>
                <li><a href="#" className="hover:text-white transition">FAQ</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Privacidade</a></li>
                <li><a href="#" className="hover:text-white transition">Termos</a></li>
                <li><a href="#" className="hover:text-white transition">Cookies</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 {APP_TITLE}. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
