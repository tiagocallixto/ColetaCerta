import {
  Lightbulb,
  Battery,
  FileText,
  Cpu,
  Leaf,
  Droplet,
  Package,
  Wine,
  Wrench,
  Shirt,
  Trees,
  Rotate3D,
  Pill,
  Hammer,
  AlertTriangle,
  Recycle,
  LucideIcon,
  Coins,
  Zap,
  Smartphone,
  Droplets,
  Boxes,
  Gem,
  Shovel,
  Flame,
} from "lucide-react";

// Maps waste type names to their corresponding Lucide icons
// Each type has a unique icon for visual distinction in the UI
export const ITEM_ICON_MAP: Record<string, LucideIcon> = {
  "Lâmpadas": Lightbulb,
  "Pilhas e Baterias": Battery,
  "Papéis e Papelão": FileText,
  "Resíduos Eletrônicos": Smartphone,
  "Resíduos Orgânicos": Leaf,
  "Óleo de Cozinha": Droplets,
  "Plásticos": Package,
  "Vidros": Gem,
  "Metais": Wrench,
  "Roupas e Têxteis": Shirt,
  "Madeira": Trees,
  "Pneus": Rotate3D,
  "Medicamentos": Pill,
  "Pilhas": Zap,
  "Alumínio": Coins,
  "Cobre": Cpu,
  "Construção": Shovel,
  "Resíduos Perigosos": AlertTriangle,
};

// Color scheme for each waste type - helps users quickly identify categories
// Using distinct colors to improve visual hierarchy and accessibility
export const ITEM_COLOR_MAP: Record<string, string> = {
  "Lâmpadas": "text-yellow-600",
  "Pilhas e Baterias": "text-red-600",
  "Papéis e Papelão": "text-blue-600",
  "Resíduos Eletrônicos": "text-purple-600",
  "Resíduos Orgânicos": "text-green-600",
  "Óleo de Cozinha": "text-orange-600",
  "Plásticos": "text-pink-600",
  "Vidros": "text-cyan-600",
  "Metais": "text-gray-600",
  "Roupas e Têxteis": "text-indigo-600",
  "Madeira": "text-amber-600",
  "Pneus": "text-slate-600",
  "Medicamentos": "text-rose-600",
  "Pilhas": "text-yellow-500",
  "Alumínio": "text-gray-500",
  "Cobre": "text-orange-700",
  "Construção": "text-stone-600",
  "Resíduos Perigosos": "text-red-700",
};

export function getItemIcon(title: string): LucideIcon {
  return ITEM_ICON_MAP[title] || Recycle;
}

export function getItemColor(title: string): string {
  return ITEM_COLOR_MAP[title] || "text-red-600";
}
