import { describe, expect, it } from "vitest";
import { z } from "zod";

const emailSchema = z.string().email("Email inválido").min(1, "Email é obrigatório");

describe("Email Validation", () => {
  it("accepts valid email formats", () => {
    const validEmails = [
      "test@example.com",
      "user.name@example.com",
      "user+tag@example.co.uk",
      "user_name@example.com",
      "123@example.com",
      "a@b.co",
    ];

    validEmails.forEach((email) => {
      const result = emailSchema.safeParse(email);
      expect(result.success).toBe(true, `Email "${email}" should be valid`);
    });
  });

  it("rejects invalid email formats", () => {
    const invalidEmails = [
      "",
      "notanemail",
      "missing@domain",
      "@example.com",
      "user@",
      "user @example.com",
      "user@example",
    ];

    invalidEmails.forEach((email) => {
      const result = emailSchema.safeParse(email);
      expect(result.success).toBe(false, `Email "${email}" should be invalid`);
    });
  });

  it("accepts emails with common domains", () => {
    const commonEmails = [
      "contact@coleta-certa.com.br",
      "info@ponto-coleta.org",
      "admin@reciclagem.gov.br",
      "support@sustainability.net",
    ];

    commonEmails.forEach((email) => {
      const result = emailSchema.safeParse(email);
      expect(result.success).toBe(true, `Email "${email}" should be valid`);
    });
  });
});
