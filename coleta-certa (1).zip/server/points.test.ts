import { describe, expect, it, beforeAll } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("items.list", () => {
  it("returns a list of items", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const items = await caller.items.list();

    expect(Array.isArray(items)).toBe(true);
    if (items.length > 0) {
      expect(items[0]).toHaveProperty("id");
      expect(items[0]).toHaveProperty("title");
      expect(items[0]).toHaveProperty("image");
    }
  });
});

describe("points.search", () => {
  it("returns empty array when no points match filters", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const results = await caller.points.search({
      city: "NonexistentCity",
      uf: "XX",
      itemIds: [1],
    });

    expect(Array.isArray(results)).toBe(true);
    expect(results.length).toBe(0);
  });

  it("returns points with correct structure", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const results = await caller.points.search({
      city: "São Paulo",
      uf: "SP",
      itemIds: [1],
    });

    if (results.length > 0) {
      const point = results[0];
      expect(point).toHaveProperty("id");
      expect(point).toHaveProperty("name");
      expect(point).toHaveProperty("email");
      expect(point).toHaveProperty("whatsapp");
      expect(point).toHaveProperty("latitude");
      expect(point).toHaveProperty("longitude");
      expect(point).toHaveProperty("city");
      expect(point).toHaveProperty("uf");
      expect(point).toHaveProperty("image");
    }
  });
});

describe("points.create", () => {
  it("validates required fields", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.points.create({
        name: "",
        email: "invalid",
        whatsapp: "",
        latitude: "0",
        longitude: "0",
        city: "",
        uf: "",
        itemIds: [],
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });

  it("validates email format", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.points.create({
        name: "Test Point",
        email: "invalid-email",
        whatsapp: "11987654321",
        latitude: "-23.5505",
        longitude: "-46.6333",
        city: "São Paulo",
        uf: "SP",
        itemIds: [1],
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toBeDefined();
    }
  });

  it("requires at least one item", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.points.create({
        name: "Test Point",
        email: "test@example.com",
        whatsapp: "11987654321",
        latitude: "-23.5505",
        longitude: "-46.6333",
        city: "São Paulo",
        uf: "SP",
        itemIds: [],
      });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.message).toContain("item");
    }
  });
});

describe("points.getById", () => {
  it("throws error for non-existent point", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.points.getById({ id: 99999 });
      expect.fail("Should have thrown an error");
    } catch (error: any) {
      expect(error.code).toBe("NOT_FOUND");
    }
  });
});
