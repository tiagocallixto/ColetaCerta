import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { getAllItems, searchPoints, getPointById, getPointItemsByPointId, createPoint, seedItems } from "./db";
import { storagePut } from "./storage";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Fetch available waste types for filtering
  items: router({
    list: publicProcedure.query(async () => {
      const itemsList = await getAllItems();
      return itemsList.map(item => ({
        id: item.id,
        title: item.title,
        image: item.image,
      }));
    }),
  }),

  // Core functionality for searching and managing collection points
  points: router({
    search: publicProcedure
      .input(
        z.object({
          city: z.string(),
          uf: z.string(),
          itemIds: z.array(z.number()),
        })
      )
      .query(async ({ input }) => {
        const searchResults = await searchPoints({
          city: input.city,
          uf: input.uf,
          itemIds: input.itemIds,
        });

        return searchResults.map(point => ({
          id: point.id,
          name: point.name,
          email: point.email,
          whatsapp: point.whatsapp,
          latitude: point.latitude,
          longitude: point.longitude,
          city: point.city,
          uf: point.uf,
          image: point.image,
        }));
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const point = await getPointById(input.id);
        if (!point) {
          throw new TRPCError({
            code: "NOT_FOUND",
            message: "Ponto de coleta não encontrado",
          });
        }

        const pointItems = await getPointItemsByPointId(input.id);

        return {
          id: point.id,
          name: point.name,
          email: point.email,
          whatsapp: point.whatsapp,
          latitude: point.latitude,
          longitude: point.longitude,
          city: point.city,
          uf: point.uf,
          image: point.image,
          items: pointItems.map(item => ({
            id: item.id,
            title: item.title,
            image: item.image,
          })),
        };
      }),

    create: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, "Nome é obrigatório"),
          email: z.string().email("Email inválido").min(1, "Email é obrigatório"),
          whatsapp: z.string().min(1, "WhatsApp é obrigatório"),
          latitude: z.string(),
          longitude: z.string(),
          city: z.string().min(1, "Cidade é obrigatória"),
          uf: z.string().length(2, "UF deve ter 2 caracteres"),
          street: z.string().min(1, "Rua é obrigatória"),
          number: z.string().min(1, "Número é obrigatório"),
          neighborhood: z.string().min(1, "Bairro é obrigatório"),
          itemIds: z.array(z.number()).min(1, "Selecione pelo menos um item"),
          imageBase64: z.string().optional(),
        }).strict()
      )
      .mutation(async ({ input }) => {
        try {
          // Handle image upload if provided
          let imageFilename = "default.jpg";
          if (input.imageBase64) {
            try {
              const buffer = Buffer.from(input.imageBase64, "base64");
              const timestamp = Date.now();
              const randomSuffix = Math.random().toString(36).substring(2, 8);
              const fileKey = `points/${timestamp}-${randomSuffix}-point.jpg`;
              const { url } = await storagePut(fileKey, buffer, "image/jpeg");
              imageFilename = url;
            } catch (uploadError) {
              console.error("Image upload failed:", uploadError);
              // Continue with default if upload fails
            }
          }

          const newPoint = await createPoint({
            name: input.name,
            email: input.email,
            whatsapp: input.whatsapp,
            latitude: input.latitude,
            longitude: input.longitude,
            city: input.city,
            uf: input.uf,
            street: input.street,
            number: input.number,
            neighborhood: input.neighborhood,
            image: imageFilename,
            itemIds: input.itemIds,
          });

          if (!newPoint) {
            throw new TRPCError({
              code: "INTERNAL_SERVER_ERROR",
              message: "Falha ao criar ponto de coleta",
            });
          }

          return {
            id: newPoint.id,
            name: newPoint.name,
            email: newPoint.email,
            whatsapp: newPoint.whatsapp,
            latitude: newPoint.latitude,
            longitude: newPoint.longitude,
            city: newPoint.city,
            uf: newPoint.uf,
            image: newPoint.image,
          };
        } catch (error) {
          console.error("Error creating point:", error);
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: "Erro ao criar ponto de coleta",
          });
        }
      }),
  }),

  // Admin operations
  admin: router({
    seedItems: publicProcedure.mutation(async () => {
      await seedItems();
      return { success: true };
    }),
  }),
});

export type AppRouter = typeof appRouter;
