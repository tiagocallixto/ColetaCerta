import { eq, inArray, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, items, points, pointItems, Item, Point, PointItem } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Item queries - used by the search and detail pages

export async function getAllItems(): Promise<Item[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get items: database not available");
    return [];
  }

  try {
    return await db.select().from(items);
  } catch (error) {
    console.error("[Database] Failed to get items:", error);
    return [];
  }
}

export async function getItemById(id: number): Promise<Item | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get item: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(items).where(eq(items.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get item:", error);
    return undefined;
  }
}

// Collection point CRUD - main business logic

export async function createPoint(data: {
  name: string;
  email: string;
  whatsapp: string;
  latitude: string;
  longitude: string;
  city: string;
  uf: string;
  street: string;
  number: string;
  neighborhood: string;
  image: string;
  itemIds: number[];
}): Promise<Point | null> {
  const db = await getDb();
  if (!db) {
    console.error("[Database] Cannot create point: database not available");
    throw new Error("Database not available");
  }

  try {
    // Validate required fields
    if (!data.name || !data.email || !data.city || !data.uf) {
      throw new Error("Missing required fields: name, email, city, uf");
    }

    if (!data.itemIds || data.itemIds.length === 0) {
      throw new Error("At least one item must be selected");
    }

    // Insert the point
    const insertResult = await db.insert(points).values({
      name: data.name,
      email: data.email,
      whatsapp: data.whatsapp,
      latitude: data.latitude,
      longitude: data.longitude,
      city: data.city,
      uf: data.uf,
      street: data.street,
      number: data.number,
      neighborhood: data.neighborhood,
      image: data.image,
    });

    // Extract the inserted ID - handle different database drivers
    let pointId: number | null = null;
    
    if (insertResult && typeof insertResult === 'object') {
      const result = insertResult as any;
      // For MySQL2 with drizzle
      if (result.insertId) {
        pointId = result.insertId;
      } else if (Array.isArray(insertResult) && insertResult.length > 0) {
        const firstItem = insertResult[0] as any;
        pointId = firstItem?.insertId || firstItem?.id;
      }
    }

    if (!pointId) {
      console.error("[Database] Failed to get inserted point ID", insertResult);
      throw new Error("Failed to get inserted point ID");
    }

    // Create point-item relationships - insert one by one to avoid drizzle issues
    if (data.itemIds.length > 0) {
      for (const itemId of data.itemIds) {
        try {
          await db.insert(pointItems).values({
            pointId: pointId,
            itemId: itemId,
          });
        } catch (itemError) {
          console.error(`[Database] Failed to insert point-item relationship for itemId ${itemId}:`, itemError);
          // Continue with other items
        }
      }
    }

    // Retrieve and return the created point
    const createdPoint = await getPointById(pointId);
    if (!createdPoint) {
      throw new Error("Failed to retrieve created point");
    }

    return createdPoint;
  } catch (error) {
    console.error("[Database] Failed to create point:", error);
    throw error;
  }
}

export async function getPointById(id: number): Promise<Point | undefined> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get point: database not available");
    return undefined;
  }

  try {
    const result = await db.select().from(points).where(eq(points.id, id)).limit(1);
    return result.length > 0 ? result[0] : undefined;
  } catch (error) {
    console.error("[Database] Failed to get point:", error);
    return undefined;
  }
}

export async function getPointItemsByPointId(pointId: number): Promise<Item[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get point items: database not available");
    return [];
  }

  try {
    const pointItemsData = await db
      .select()
      .from(pointItems)
      .where(eq(pointItems.pointId, pointId));

    if (pointItemsData.length === 0) {
      return [];
    }

    const itemIds = pointItemsData.map(pi => pi.itemId);
    const itemsData = await db
      .select()
      .from(items)
      .where(inArray(items.id, itemIds));

    return itemsData;
  } catch (error) {
    console.error("[Database] Failed to get point items:", error);
    return [];
  }
}

export async function searchPoints(filters: {
  city: string;
  uf: string;
  itemIds: number[];
}): Promise<Point[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot search points: database not available");
    return [];
  }

  try {
    // First, get all point_items that match the requested items
    const matchingPointItems = await db
      .select({ pointId: pointItems.pointId })
      .from(pointItems)
      .where(inArray(pointItems.itemId, filters.itemIds));

    const pointIds = matchingPointItems.map(pi => pi.pointId);

    if (pointIds.length === 0) {
      return [];
    }

    // Then get points that match the location and have the requested items
    const result = await db
      .select()
      .from(points)
      .where(
        and(
          inArray(points.id, pointIds),
          eq(points.city, filters.city),
          eq(points.uf, filters.uf)
        )
      );

    return result;
  } catch (error) {
    console.error("[Database] Failed to search points:", error);
    return [];
  }
}

// Database initialization

export async function seedItems(): Promise<void> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot seed items: database not available");
    return;
  }

  try {
    const existingItems = await getAllItems();
    if (existingItems.length > 0) {
      console.log("[Database] Items already seeded, skipping");
      return;
    }

    const seedData = [
      { title: 'Lâmpadas', image: 'lampadas.svg' },
      { title: 'Pilhas e Baterias', image: 'baterias.svg' },
      { title: 'Papéis e Papelão', image: 'papeis-papelao.svg' },
      { title: 'Resíduos Eletrônicos', image: 'eletronicos.svg' },
      { title: 'Resíduos Orgânicos', image: 'organicos.svg' },
      { title: 'Óleo de Cozinha', image: 'oleo.svg' },
    ];

    await db.insert(items).values(seedData);
    console.log("[Database] Items seeded successfully");
  } catch (error) {
    console.error("[Database] Failed to seed items:", error);
  }
}
