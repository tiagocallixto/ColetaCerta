ALTER TABLE `points` ADD `street` varchar(255) NOT NULL;--> statement-breakpoint
ALTER TABLE `points` ADD `number` varchar(20) NOT NULL;--> statement-breakpoint
ALTER TABLE `points` ADD `neighborhood` varchar(255) NOT NULL;